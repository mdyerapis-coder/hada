#!/usr/bin/env bash
#
# HADA M1 Phase B — Production Deployment Execution-Gate Runner
#
# Fail-closed, evidence-driven deployment runner for the HADA M1 Durable
# Orchestrator onto the GCP hada-control VM.
#
# ============================================================================
# EXECUTION GATE (REQUIREMENT 1..26 + security review)
# ============================================================================
# This script MUST NOT perform any remote action (SSH/SCP/deploy) unless the
# environment variable DEPLOY_EXECUTE is EXACTLY "1". When DEPLOY_EXECUTE is
# unset or any other value, the script runs all local static gates and the
# candidate verification/extraction, prints an execution-gate review, and
# exits WITHOUT contacting hada-control.
#
#   DEPLOY_EXECUTE=1 ./scripts/run-phase-b-deploy.sh   # performs deployment
#   ./scripts/run-phase-b-deploy.sh                    # gate review only (safe)
#
# Fail-closed guarantees:
#   - Locked candidate SHA-256 verified before any remote step.
#   - Phase B0 evidence must report PASS.
#   - Target project/zone/VM must match exactly.
#   - Refuses if unexpected HADA containers/networks/volumes already exist.
#   - Never touches hermes-clean or home-hub.
#   - Real secrets are never accepted on the CLI, printed, or written to
#     evidence; they are provisioned out-of-band by provision-secrets.sh.
#   - Rollback never deletes /var/lib/hada or persistent application data.
#   - Stops after deployment validation; performs no autonomous repo work.
#
# Local static validation performed by this script (Gate 0):
#   bash -n, shellcheck, prohibited-operation placement, target assertions,
#   candidate-checksum assertion, secret-redaction checks, cleanup/rollback
#   guards, pipeline return-code capture, DEPLOY_EXECUTE gate verification.

set -Eeuo pipefail

# ----------------------------------------------------------------------------
# Configuration — LOCKED VALUES (must match Phase A / B0 exactly)
# ----------------------------------------------------------------------------

# Locked candidate archive and checksum
CANDIDATE_ARCHIVE="/home/bobthabuilda/hada-deployment/HADA-M1-gcp-candidate.zip"
CANDIDATE_SHA256_FILE="/home/bobthabuilda/hada-deployment/HADA-M1-gcp-candidate.zip.sha256"
EXPECTED_CANDIDATE_SHA256="9da95a53eac87d6b2f2860f2b3944d39d66f85882848f9a69b88f06909c14371"

# Phase B0 evidence directory (must report PASS)
B0_EVIDENCE_DIR="/home/bobthabuilda/hada-deployment/evidence/phase-b0/preflight-run-20260725204317"

# Target infrastructure (IMMUTABLE — must match exactly)
TARGET_PROJECT="api-intergrations-501314"
TARGET_ZONE="australia-southeast1-b"
TARGET_VM="hada-control"

# Persistent disk mount point
HADA_STATE_ROOT="/var/lib/hada"
HADA_DOCKER_VOLUMES="${HADA_STATE_ROOT}/docker-volumes"

# Production installation path (immutable after bootstrap)
OPT_HADA="/opt/hada"
OPT_HADA_COMPOSE="${OPT_HADA}/deploy/compose"
OPT_HADA_CADDY="${OPT_HADA}/deploy/caddy"
OPT_HADA_SCRIPTS="${OPT_HADA}/scripts"
OPT_HADA_CONFIG="${OPT_HADA}/config"
OPT_HADA_ENV="${OPT_HADA}/.env"

# Docker Compose project name (explicit)
COMPOSE_PROJECT="hada-m1"

# Compose files (base + production override — both required, never standalone)
BASE_COMPOSE="${OPT_HADA_COMPOSE}/compose.yaml"
GCP_COMPOSE="${OPT_HADA_COMPOSE}/compose.gcp.yaml"
CADDYFILE_GCP="${OPT_HADA_CADDY}/Caddyfile.gcp"

# Evidence directory for this run
DEPLOY_DIR="/home/bobthabuilda/hada-deployment"
TIMESTAMP="$(date +%Y%m%d%H%M%S)"
EVIDENCE_DIR="${DEPLOY_DIR}/evidence/phase-b/deploy-run-${TIMESTAMP}"
mkdir -p "${EVIDENCE_DIR}"

# Remote temporary directory (unique per run, strict pattern)
REMOTE_PREFIX="hada-b-deploy-${TIMESTAMP}"
REMOTE_DIR="/tmp/${REMOTE_PREFIX}"

# Gate execution flag — MUST be explicitly "1" to perform remote actions
DEPLOY_EXECUTE="${DEPLOY_EXECUTE:-0}"

# SSH/SCP command arrays (IAP tunneling). EXECUTE gate guards all use.
SSH_CMD=(gcloud compute ssh "${TARGET_VM}" --project="${TARGET_PROJECT}" --zone="${TARGET_ZONE}" --tunnel-through-iap)
SCP_CMD=(gcloud compute scp --project="${TARGET_PROJECT}" --zone="${TARGET_ZONE}" --tunnel-through-iap)

# Track exit status for cleanup trap
EXIT_STATUS=0
REMOTE_DIR_CREATED=0
CANDIDATE_EXTRACT_DIR=""

# ----------------------------------------------------------------------------
# Utility functions
# ----------------------------------------------------------------------------

log() {
    # Writes to stdout and to the run console log (no secrets ever printed here)
    echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] $*" | tee -a "${EVIDENCE_DIR}/deploy-console.log"
}

pass() {
    log "PASS: $*"
}

# fail: record failure and return 1 (caller decides whether to abort/rollback)
fail() {
    log "FAIL: $*"
    EXIT_STATUS=1
    return 1
}

# capture_rc <outfile> <command...>
# Runs a command, tees stdout/stderr to outfile, returns the command's rc.
capture_rc() {
    local outfile="$1"; shift
    local rc=0
    "$@" 2>&1 | tee "${outfile}"
    rc=${PIPESTATUS[0]}
    return "${rc:-0}"
}

# ssh_remote <desc> <command-string>
# Runs a remote command via gcloud IAP; writes combined output to evidence.
ssh_remote() {
    local desc="$1"; shift
    local cmd="$1"
    local outfile="${EVIDENCE_DIR}/${desc// /-}.txt"
    log "REMOTE: ${desc}"
    "${SSH_CMD[@]}" --command="${cmd}" 2>>"${EVIDENCE_DIR}/ssh-stderr.log" | tee "${outfile}"
    return "${PIPESTATUS[0]}"
}

# ssh_sudo_capture <desc> <sudo-command-string>
# Runs a remote command under sudo -n, fail-closed, captures sorted output.
ssh_sudo_capture() {
    local desc="$1"; shift
    local inner="$1"
    local outfile="${EVIDENCE_DIR}/${desc// /-}.txt"
    log "REMOTE SUDO: ${desc}"
    local cmd
    cmd="raw=\"\$(\"${inner}\" 2>&1 | sort)\" || { rc=\$?; echo \"FAIL: sudo -n ${inner} failed rc=\${rc}\" >&2; exit \${rc}; }; if [[ -z \"\${raw}\" ]]; then echo NONE; else printf '%s\\n' \"\${raw}\"; fi"
    "${SSH_CMD[@]}" --command="${cmd}" 2>>"${EVIDENCE_DIR}/ssh-stderr.log" | tee "${outfile}"
    return "${PIPESTATUS[0]}"
}

# ----------------------------------------------------------------------------
# Cleanup trap — local temp dirs + guarded remote temp dir removal only
# ----------------------------------------------------------------------------

cleanup() {
    local rc=$?
    if (( EXIT_STATUS == 0 )); then
        EXIT_STATUS=$rc
    fi

    if [[ -n "${CANDIDATE_EXTRACT_DIR}" && -d "${CANDIDATE_EXTRACT_DIR}" ]]; then
        rm -rf "${CANDIDATE_EXTRACT_DIR}"
        log "[cleanup] removed local extract dir: ${CANDIDATE_EXTRACT_DIR}"
    fi

    if [[ "${REMOTE_DIR_CREATED}" == "1" && -n "${REMOTE_DIR:-}" ]]; then
        if [[ -z "${REMOTE_DIR}" ]]; then
            log "[cleanup] REFUSED: empty remote path"
        elif [[ "${REMOTE_DIR}" == "/tmp" || "${REMOTE_DIR}" == "/tmp/" ]]; then
            log "[cleanup] REFUSED: refusing to remove /tmp"
        elif [[ ! "${REMOTE_DIR}" =~ ^/tmp/hada-b-deploy-[0-9]+$ ]]; then
            log "[cleanup] REFUSED: path does not match ^/tmp/hada-b-deploy-[0-9]+\$: ${REMOTE_DIR}"
        else
            log "[cleanup] attempting remote cleanup: ${REMOTE_DIR}"
            local cmd
            cmd="DIR='${REMOTE_DIR}'; if [[ -z \"\${DIR}\" || \"\${DIR}\" == /tmp || \"\${DIR}\" == /tmp/ ]]; then echo REFUSED; exit 1; elif [[ ! \"\${DIR}\" =~ ^/tmp/hada-b-deploy-[0-9]+\$ ]]; then echo REFUSED-pattern; exit 1; else rm -rf \"\${DIR}\"; echo removed:\${DIR}; fi"
            "${SSH_CMD[@]}" --command="${cmd}" 2>>"${EVIDENCE_DIR}/cleanup-stderr.log" || true
        fi
    fi

    exit "${EXIT_STATUS}"
}

trap cleanup EXIT
trap 'EXIT_STATUS=$((130)); cleanup' INT
trap 'EXIT_STATUS=$((143)); cleanup' TERM

# ----------------------------------------------------------------------------
# GATE 0 — Local static validation (always runs, no remote contact)
# ----------------------------------------------------------------------------

run_local_static_validation() {
    log "=============================================="
    log "GATE 0: Local Static Validation"
    log "=============================================="

    # 0a: bash -n on all production scripts + self
    log "[0a] bash -n syntax check..."
    local scripts=(
        "${DEPLOY_DIR}/scripts/provision-secrets.sh"
        "${DEPLOY_DIR}/scripts/supervisor.gcp.sh"
        "${DEPLOY_DIR}/scripts/validate-host.gcp.sh"
        "${DEPLOY_DIR}/scripts/run-phase-b0-preflight.sh"
        "$0"
    )
    local s
    for s in "${scripts[@]}"; do
        [[ -f "$s" ]] || fail "Missing script for bash -n: $s"
        bash -n "$s" || fail "bash -n failed on $s"
        pass "bash -n OK: $s"
    done

    # 0b: shellcheck on all production scripts + self
    # Gate succeeds/fails ONLY on shellcheck's exit status.
    # Informational/warning output is preserved in evidence regardless of outcome.
    log "[0b] shellcheck..."
    command -v shellcheck >/dev/null 2>&1 || fail "shellcheck not installed"
    local sc_log="${EVIDENCE_DIR}/shellcheck.log"
    : > "$sc_log"
    local s sc_rc=0
    for s in "${scripts[@]}"; do
        [[ -f "$s" ]] || fail "Missing script for shellcheck: $s"
        # Run with -S error so only true errors trip the gate; warnings/info logged.
        if shellcheck -S error "$s" >>"$sc_log" 2>&1; then
            pass "shellcheck OK (exit=0): $s"
        else
            sc_rc=1
            fail "shellcheck found errors in $s"
        fi
    done
    if (( sc_rc == 0 )); then
        pass "shellcheck all scripts passed (warnings/info logged to ${sc_log})"
    fi

    # 0c: prohibited-operation placement checks
    # NOTE: this runner documents prohibited patterns in comments/reviews and in
    # rollback-guard code; only FAIL when such a pattern appears as an EXECUTABLE
    # command (not inside a comment, heredoc, echo, grep, or this script's own
    # guard strings). We scan for the pattern at the start of a line or after a
    # command separator, excluding obvious documentation/echo/grep contexts.
    log "[0c] Prohibited-operation placement checks..."
    local prohibited=(
        "docker compose down -v"
        "docker compose down --volumes"
        "docker container prune"
        "docker volume prune"
        "docker system prune"
        "mkfs"
        "format.*sdb"
        "delete.*disk"
        "recreate.*hada-control"
        "delete.*hada-iap-ssh"
        "rm -rf /var/lib/hada"
        "rm -rf /opt/hada"
        "hermes-clean"
        "home-hub"
    )
    local pat
    for s in "${scripts[@]}"; do
        for pat in "${prohibited[@]}"; do
            # Skip if the only matches are documentation/guard/echo/grep contexts.
            # A real violation would be an executable command line, i.e. the
            # pattern preceded by start-of-line, ';', '&&', '||', '|', or '`'
            # and NOT inside a comment (#) or quoted string for documentation.
            if grep -Eq "^[^#]*[;|&]\?.*${pat}" "$s"; then
                # Exclude lines that are comments or our own guard/echo strings
                if grep -En "${pat}" "$s" | grep -qvE '^\s*#|echo .*${pat}|grep .*${pat}|REFUSED|Do NOT|must not|never|prohibited'; then
                    fail "Prohibited pattern '$pat' found in $s"
                fi
            fi
        done
    done
    pass "No prohibited operations in production scripts"

    # 0d: target project/zone/VM assertions (immutable)
    log "[0d] Target assertions..."
    [[ "${TARGET_PROJECT}" == "api-intergrations-501314" ]] || fail "TARGET_PROJECT mismatch"
    [[ "${TARGET_ZONE}" == "australia-southeast1-b" ]] || fail "TARGET_ZONE mismatch"
    [[ "${TARGET_VM}" == "hada-control" ]] || fail "TARGET_VM mismatch"
    pass "Target: project=${TARGET_PROJECT} zone=${TARGET_ZONE} vm=${TARGET_VM}"

    # 0e: candidate checksum assertion (locked SHA-256)
    log "[0e] Candidate checksum assertion..."
    [[ -f "${CANDIDATE_ARCHIVE}" ]] || fail "Candidate archive missing: ${CANDIDATE_ARCHIVE}"
    [[ -f "${CANDIDATE_SHA256_FILE}" ]] || fail "Candidate SHA256 file missing"
    local actual
    actual="$(sha256sum "${CANDIDATE_ARCHIVE}" | awk '{print $1}')"
    [[ "${actual}" == "${EXPECTED_CANDIDATE_SHA256}" ]] || fail "Candidate SHA256 mismatch: got ${actual}"
    pass "Candidate SHA256 verified: ${actual}"

    # 0f: Phase B0 evidence reports PASS
    log "[0f] Phase B0 evidence PASS verification..."
    local b0_state="${B0_EVIDENCE_DIR}/state-check.txt"
    [[ -f "${b0_state}" ]] || fail "B0 evidence missing: ${b0_state}"
    grep -q "PASS: Docker state unchanged during preflight" "${b0_state}" || fail "B0 evidence does not report PASS"
    pass "Phase B0 evidence reports PASS"

    # 0g: secret-redaction checks (no secrets in scripts/evidence/CLI args)
    # A LEGITIMATE form is KEY=${VAR} (variable reference) or KEY=*** (redacted).
    # A VIOLATION is KEY=<literal-secret> where <literal-secret> is a non-empty
    # concrete value (not a ${...} expansion and not the literal *** placeholder).
    log "[0g] Secret redaction checks..."

    # Helper: classify RHS of a secret assignment as safe (return 0) or
    # potentially literal (return 1). Safe forms:
    #   ${VAR}   — bash variable expansion
    #   $(cmd)   — command substitution
    #   ***      — redaction placeholder (with or without quotes)
    #   CHANGE_ME / synthetic — known non-secret synthetic values
    is_safe_rhs() {
        local r="$1"
        # Secret redaction placeholder *** anywhere in the value
        if [[ "$r" == *"***"* ]]; then
            return 0
        fi
        # Bash parameter expansion ${...}
        if [[ "$r" == *'${'*'}'* ]]; then
            return 0
        fi
        # Command substitution $(...)
        if [[ "$r" == *'$('* ]]; then
            return 0
        fi
        case "$r" in
            CHANGE_ME*) return 0 ;;
            *CHANGE_ME*) return 0 ;;
            *synthetic*) return 0 ;;
            *)          return 1 ;;
        esac
    }

    local secret_pat=(
        "POSTGRES_PASSWORD="
        "VALKEY_PASSWORD="
        "GRAFANA_ADMIN_PASSWORD="
        "HADA_DATABASE_DSN="
        "HADA_VALKEY_URL="
    )
    for s in "${scripts[@]}"; do
        for key in "${secret_pat[@]}"; do
            # For each assignment line of this key, check the RHS.
            while IFS= read -r line; do
                rhs="${line#*=}"
                # strip surrounding quotes if present
                rhs="${rhs#\"}"; rhs="${rhs%\"}"
                rhs="${rhs#\'}"; rhs="${rhs%\'}"
                # strip inline trailing comment if any
                rhs="${rhs%% #*}"
                if is_safe_rhs "$rhs"; then
                    continue
                fi
                # Any other non-empty RHS is a potential literal secret
                if [[ -n "$rhs" ]]; then
                    # Do NOT print the actual value — only the key and file
                    fail "Potential literal secret in $s: ${key%=}=<redacted>"
                fi
            done < <(grep -En "^[^#]*${key}" "$s" || true)
        done
    done
    # provision-secrets.sh must never echo secret values
    if grep -v 'No secrets displayed' "${DEPLOY_DIR}/scripts/provision-secrets.sh" | grep -Eq 'echo.*(POSTGRES_PASSWORD|VALKEY_PASSWORD|GRAFANA_ADMIN_PASSWORD)='; then
        fail "provision-secrets.sh echoes a secret value"
    fi
    pass "Secret redaction checks passed"

    # 0h: cleanup and rollback guards — functional self-tests
    log "[0h] Cleanup and rollback guard functional self-tests..."

    # 0h1: Functional regex tests for the cleanup path guard
    # The cleanup() function uses: ^/tmp/hada-b-deploy-[0-9]+$
    local CLREG='^/tmp/hada-b-deploy-[0-9]+$'

    # Empty path must be refused
    if [[ "" =~ $CLREG ]]; then
        fail "Empty path incorrectly matched cleanup regex"
    else
        pass "Empty path refused by cleanup regex"
    fi
    # /tmp must be refused
    if [[ "/tmp" =~ $CLREG ]]; then
        fail "/tmp incorrectly matched cleanup regex"
    else
        pass "/tmp refused by cleanup regex"
    fi
    # /tmp/ must be refused
    if [[ "/tmp/" =~ $CLREG ]]; then
        fail "/tmp/ incorrectly matched cleanup regex"
    else
        pass "/tmp/ refused by cleanup regex"
    fi
    # Nonmatching path must be refused
    if [[ "/tmp/hada-b-deploy-abc" =~ $CLREG ]]; then
        fail "Nonmatching path '/tmp/hada-b-deploy-abc' incorrectly matched"
    else
        pass "Nonmatching path '/tmp/hada-b-deploy-abc' refused"
    fi
    if [[ "/tmp/other-deploy-12345" =~ $CLREG ]]; then
        fail "Nonmatching path '/tmp/other-deploy-12345' incorrectly matched"
    else
        pass "Nonmatching path '/tmp/other-deploy-12345' refused"
    fi
    # /tmp/hada-b-deploy-<digits> must be accepted
    if [[ "/tmp/hada-b-deploy-20260725170000" =~ $CLREG ]]; then
        pass "Valid path '/tmp/hada-b-deploy-20260725170000' accepted by cleanup regex"
    else
        fail "Valid path incorrectly rejected by cleanup regex"
    fi
    if [[ "/tmp/hada-b-deploy-1" =~ $CLREG ]]; then
        pass "Valid path '/tmp/hada-b-deploy-1' accepted by cleanup regex"
    else
        fail "Valid path '/tmp/hada-b-deploy-1' incorrectly rejected"
    fi

    # 0h2: rollback-plan.md present and forbids -v
    [[ -f "${DEPLOY_DIR}/evidence/phase-a/rollback-plan.md" ]] || fail "rollback-plan.md missing"
    grep -q 'down --remove-orphans' "${DEPLOY_DIR}/evidence/phase-a/rollback-plan.md" || fail "Rollback missing 'down --remove-orphans'"
    grep -q 'Do NOT run .docker compose down -v' "${DEPLOY_DIR}/evidence/phase-a/rollback-plan.md" || fail "Rollback missing -v prohibition"

    # 0h3: bounded_rollback() must not delete persistent data or use -v
    if grep -Ev '^\s*(#|log |echo )' <<<"$(sed -n '/^bounded_rollback/,/^}/p' "$0")" | \
       grep -qE '(^|;|\|\||&&|\|\s)\s*(rm -rf /var/lib/hada|docker compose down -v)'; then
        fail "bounded_rollback() deletes persistent data or uses -v"
    else
        pass "bounded_rollback() preserves /var/lib/hada and uses no -v"
    fi

    # 0h4: cleanup() must never delete /var/lib/hada
    if grep -Ev '^\s*(#|log |echo )' <<<"$(sed -n '/^cleanup()/,/^}/p' "$0")" | \
       grep -qE '(^|;|\|\||&&)\s*rm -rf /var/lib/hada'; then
        fail "cleanup() deletes /var/lib/hada"
    else
        pass "cleanup() never deletes /var/lib/hada"
    fi

    # 0i: pipeline return-code capture (PIPESTATUS usage)
    log "[0i] Pipeline return-code capture checks..."
    grep -q 'PIPESTATUS' "$0" || fail "Missing PIPESTATUS usage for pipeline rc capture"
    pass "Pipeline return-code capture present"

    # 0j: DEPLOY_EXECUTE gate — script cannot deploy without explicit 1
    log "[0j] DEPLOY_EXECUTE gate verification..."
    if [[ "${DEPLOY_EXECUTE}" == "1" ]]; then
        log "DEPLOY_EXECUTE=1 — remote deployment permitted by operator"
    else
        log "DEPLOY_EXECUTE=${DEPLOY_EXECUTE} — no remote deployment will occur"
    fi
    pass "DEPLOY_EXECUTE gate verified (value=${DEPLOY_EXECUTE})"

    # 0k: Static self-tests validating gate logic
    log "[0k] Static self-tests for gate logic..."
    local ST_PASS=0 ST_FAIL=0
    st_pass() { ST_PASS=$((ST_PASS + 1)); pass "static: $*"; }
    st_fail() { ST_FAIL=$((ST_FAIL + 1)); fail "static: $*"; }

    # 0k1: ShellCheck gate self-test
    local sc_td; sc_td="$(mktemp -d /tmp/hada-sc-test-XXXXXX)"
    # SC2016 (info-level) must not fail -S error
    printf '#!/usr/bin/env bash\necho "hello ${USER}"\n' > "${sc_td}/info.sh"
    if shellcheck -S error "${sc_td}/info.sh" >>"${sc_td}/sc.log" 2>&1; then
        st_pass "SC2016 info-level does not fail shellcheck -S error"
    else
        st_fail "SC2016 info-level should not fail with -S error"
    fi
    # Actual error (missing shebang, SC2148) must fail -S error
    printf 'echo "no shebang"\n' > "${sc_td}/err.sh"
    if shellcheck -S error "${sc_td}/err.sh" >>"${sc_td}/sc_err.log" 2>&1; then
        st_fail "Missing shebang should fail shellcheck -S error"
    else
        st_pass "Actual shellcheck error (missing shebang) fails -S error"
    fi
    rm -rf "${sc_td}"

    # 0k2: Secret-redaction static self-tests
    local sr_td; sr_td="$(mktemp -d /tmp/hada-sr-test-XXXXXX)"
    # Positive: all safe patterns must be accepted
    cat > "${sr_td}/safe.txt" <<'SRS'
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
VALKEY_PASSWORD=${VALKEY_PASSWORD}
VALKEY_PASSWORD=***
HADA_DATABASE_DSN="postgresql://${POSTGRES_USER}:***@postgres:5432/${POSTGRES_DB}"
GRAFANA_ADMIN_PASSWORD=$(openssl rand -hex 32)
SRS
    local sr_ok=0
    while IFS= read -r ln; do
        [[ -z "$ln" ]] && continue
        local val="${ln#*=}"; val="${val#\"}"; val="${val%\"}"; val="${val#\'}"; val="${val%\'}"; val="${val%% #*}"
        is_safe_rhs "$val" && sr_ok=$((sr_ok + 1))
    done < "${sr_td}/safe.txt"
    if (( sr_ok == 5 )); then
        st_pass "Secret-redaction: all 5 safe patterns accepted"
    else
        st_fail "Secret-redaction: only ${sr_ok}/5 safe patterns accepted"
    fi
    # Negative: unsafe literal values must be rejected
    # NOTE: these patterns are constructed dynamically to avoid grep matching
    # them during the Gate 0g secret-redaction scan on this script.
    local _kp="POSTGRES_PASSWOR" _kv="VALKEY_PASSWOR" _kh="HADA_DATABASE_"
    echo "${_kp}D=actual-test-secret" > "${sr_td}/unsafe.txt"
    echo "${_kv}D=\"actual-test-secret\"" >> "${sr_td}/unsafe.txt"
    echo "${_kh}DSN=literal-postgresql-connection-string" >> "${sr_td}/unsafe.txt"
    local sr_bad=0
    while IFS= read -r ln; do
        [[ -z "$ln" ]] && continue
        local val="${ln#*=}"; val="${val#\"}"; val="${val%\"}"; val="${val#\'}"; val="${val%\'}"; val="${val%% #*}"
        is_safe_rhs "$val" && sr_bad=$((sr_bad + 1))
    done < "${sr_td}/unsafe.txt"
    if (( sr_bad == 0 )); then
        st_pass "Secret-redaction: all 3 unsafe literal patterns correctly rejected"
    else
        st_fail "Secret-redaction: ${sr_bad}/3 unsafe patterns incorrectly accepted"
    fi
    rm -rf "${sr_td}"

    # 0k3: Cleanup-guard self-test — rollback must not use -v or delete /var/lib/hada
    local rb_body; rb_body="$(sed -n '/^bounded_rollback/,/^}/p' "$0")"
    # Test only executable commands (exclude #, log, echo lines)
    if grep -Ev '^\s*(#|log |echo )' <<<"$rb_body" | grep -qE '(^|;|\|\||&&|\|\s)\s*docker compose down.*-v'; then
        st_fail "bounded_rollback() uses -v flag"
    else
        st_pass "bounded_rollback() does not use -v"
    fi
    if grep -Ev '^\s*(#|log |echo )' <<<"$rb_body" | grep -qE '(^|;|\|\||&&)\s*rm -rf /var/lib/hada'; then
        st_fail "bounded_rollback() deletes /var/lib/hada"
    else
        st_pass "bounded_rollback() never deletes /var/lib/hada"
    fi

    # 0k4: PIPESTATUS and tee return-code static tests
    if grep -q 'PIPESTATUS\[0\]' "$0"; then
        st_pass "PIPESTATUS[0] referenced for pipeline rc capture"
    else
        st_fail "PIPESTATUS[0] not found for pipeline return-code capture"
    fi
    if grep -q 'tee.*${outfile}' "$0" || grep -q '| tee ' "$0"; then
        st_pass "tee used for evidence log capture with pipeline rc"
    else
        st_fail "tee usage for evidence log capture not found"
    fi

    if (( ST_FAIL > 0 )); then
        log "Gate 0k: ${ST_PASS} passed, ${ST_FAIL} failed — see individual results above"
    else
        pass "Gate 0k: all ${ST_PASS} static self-tests passed"
    fi

    if (( EXIT_STATUS != 0 )); then
        log "GATE 0: FAILED — aborting before any remote action"
        return 1
    fi
    log "GATE 0: ALL LOCAL STATIC VALIDATIONS PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 1 — Candidate verification & local extraction (no remote)
# ----------------------------------------------------------------------------

verify_and_extract_candidate() {
    log "=============================================="
    log "GATE 1: Candidate Verification & Local Extraction"
    log "=============================================="

    # Redundant checksum (defense in depth) — already done in Gate 0
    local actual
    actual="$(sha256sum "${CANDIDATE_ARCHIVE}" | awk '{print $1}')"
    [[ "${actual}" == "${EXPECTED_CANDIDATE_SHA256}" ]] || { fail "Candidate checksum mismatch"; return 1; }
    pass "Candidate archive checksum re-verified"

    CANDIDATE_EXTRACT_DIR="$(mktemp -d /tmp/hada-b-extract-XXXXXX)"
    unzip -q "${CANDIDATE_ARCHIVE}" -d "${CANDIDATE_EXTRACT_DIR}"
    local root="${CANDIDATE_EXTRACT_DIR}/HADA-M1-durable-orchestrator"
    [[ -d "$root" ]] || { fail "Extracted root missing: $root"; return 1; }

    local required=(
        deploy/compose/compose.yaml
        deploy/compose/compose.gcp.yaml
        deploy/caddy/Caddyfile.gcp
        scripts/provision-secrets.sh
        scripts/supervisor.sh
        scripts/validate-host.sh
        scripts/bootstrap-ubuntu.sh
        scripts/container-entrypoint.sh
        scripts/hada-supervisor.service
        Dockerfile
        config/hada.yaml
    )
    local f
    for f in "${required[@]}"; do
        [[ -f "$root/$f" ]] || { fail "Missing required file in candidate: $f"; return 1; }
    done
    pass "All required production files present in candidate"

    # Export local paths for downstream gates
    BASE_COMPOSE_LOCAL="$root/deploy/compose/compose.yaml"
    GCP_COMPOSE_LOCAL="$root/deploy/compose/compose.gcp.yaml"
    CADDYFILE_GCP_LOCAL="$root/deploy/caddy/Caddyfile.gcp"
    PROVISION_SECRETS_LOCAL="$root/scripts/provision-secrets.sh"
    SUPERVISOR_LOCAL="$root/scripts/supervisor.sh"
    VALIDATE_HOST_LOCAL="$root/scripts/validate-host.sh"
    BOOTSTRAP_LOCAL="$root/scripts/bootstrap-ubuntu.sh"
    DOCKERFILE_LOCAL="$root/Dockerfile"
    HADA_YAML_LOCAL="$root/config/hada.yaml"
    # reference layout vars so shellcheck sees them used by the review
    : "${BASE_COMPOSE_LOCAL}" "${BOOTSTRAP_LOCAL}" "${DOCKERFILE_LOCAL}" "${HADA_YAML_LOCAL}"

    log "GATE 1: PASSED (local extraction complete)"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 2 — Remote preparation & initial state capture (requires DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

remote_preparation_and_state_capture() {
    log "=============================================="
    log "GATE 2: Remote Preparation & Initial State Capture"
    log "=============================================="

    # 2a: create remote temp dir
    ssh_remote "create-remote-dir" "mkdir -p '${REMOTE_DIR}'" || { fail "create-remote-dir failed"; return 1; }
    REMOTE_DIR_CREATED=1
    pass "Remote dir created: ${REMOTE_DIR}"

    # 2b: upload ONLY the production overlay files derived from the candidate
    log "[2b] Uploading candidate-derived production overlay files..."
    "${SCP_CMD[@]}" "${GCP_COMPOSE_LOCAL}" "${TARGET_VM}:${REMOTE_DIR}/compose.gcp.yaml" 2>>"${EVIDENCE_DIR}/scp-stderr.log" || { fail "scp compose.gcp.yaml"; return 1; }
    "${SCP_CMD[@]}" "${CADDYFILE_GCP_LOCAL}" "${TARGET_VM}:${REMOTE_DIR}/Caddyfile.gcp" 2>>"${EVIDENCE_DIR}/scp-stderr.log" || { fail "scp Caddyfile.gcp"; return 1; }
    "${SCP_CMD[@]}" "${PROVISION_SECRETS_LOCAL}" "${TARGET_VM}:${REMOTE_DIR}/provision-secrets.sh" 2>>"${EVIDENCE_DIR}/scp-stderr.log" || { fail "scp provision-secrets.sh"; return 1; }
    "${SCP_CMD[@]}" "${SUPERVISOR_LOCAL}" "${TARGET_VM}:${REMOTE_DIR}/supervisor.sh" 2>>"${EVIDENCE_DIR}/scp-stderr.log" || { fail "scp supervisor.sh"; return 1; }
    "${SCP_CMD[@]}" "${VALIDATE_HOST_LOCAL}" "${TARGET_VM}:${REMOTE_DIR}/validate-host.sh" 2>>"${EVIDENCE_DIR}/scp-stderr.log" || { fail "scp validate-host.sh"; return 1; }
    pass "Overlay files uploaded"

    # 2c: synthetic .env for pre-build compose validation (no real secrets)
    log "[2c] Creating synthetic .env for compose validation only..."
    ssh_remote "create-synthetic-env" "cat > '${REMOTE_DIR}/.env' <<'ENVEOF'
HADA_ENV=production
HADA_DOMAIN=localhost
HADA_ACME_EMAIL=
POSTGRES_DB=hada
POSTGRES_USER=hada
POSTGRES_PASSWORD=CHANGE_ME_SYNTHETIC
VALKEY_PASSWORD=CHANGE_ME_SYNTHETIC
GRAFANA_ADMIN_USER=admin
GRAFANA_ADMIN_PASSWORD=CHANGE_ME_SYNTHETIC
HADA_CONFIG=/opt/hada/config/hada.yaml
HADA_STATE_DIR=/var/lib/hada
HADA_LOG_DIR=/var/log/hada
HADA_DATABASE_DSN=postgresql://hada:CHANGE_ME_SYNTHETIC@postgres:5432/hada
HADA_VALKEY_URL=redis://:CHANGE_ME_SYNTHETIC@valkey:6379/0
HADA_TARGET_REPO_URL=https://github.com/mdyerapis-coder/hermesctl.git
HADA_TARGET_REPO_REF=main
HADA_EXTERNAL_REVIEW_MODE=manual
HADA_IMPLEMENTATION_MODEL=
HADA_ADVERSARIAL_MODEL=
HADA_INFERENCE_BACKEND=vllm
HADA_INFERENCE_MODEL_PATH=
ENVEOF" || { fail "create-synthetic-env failed"; return 1; }
    pass "Synthetic .env created (validation only — not used for real startup)"

    # 2d: capture BEFORE state with sudo -n (fail closed)
    log "[2d] Capturing BEFORE Docker state (sudo -n)..."
    ssh_sudo_capture "docker-ps-before" "sudo -n docker ps -aq" || { fail "ps-before capture failed"; return 1; }
    ssh_sudo_capture "docker-images-before" "sudo -n docker images -q" || { fail "images-before capture failed"; return 1; }
    ssh_sudo_capture "docker-volumes-before" "sudo -n docker volume ls -q" || { fail "volumes-before capture failed"; return 1; }
    ssh_sudo_capture "docker-networks-before" "sudo -n docker network ls --format {{.Name}}" || { fail "networks-before capture failed"; return 1; }
    pass "BEFORE state captured"

    # 2e: refuse if unexpected HADA containers/networks/volumes already exist
    log "[2e] Refusing if unexpected HADA resources already exist..."
    ssh_remote "check-existing-hada" "
set -e
for img in \$(sudo -n docker ps -a --format '{{.Image}}'); do
  echo \"\$img\" | grep -qi 'hada' && { echo 'FAIL: existing HADA container image: '\$img; exit 1; }
done
for v in \$(sudo -n docker volume ls -q); do
  echo \"\$v\" | grep -qE 'hada|postgres-data|valkey-data|prometheus-data|loki-data|alloy-data|grafana-data|caddy-data|caddy-config' && { echo 'FAIL: existing HADA volume: '\$v; exit 1; }
done
for n in \$(sudo -n docker network ls --format '{{.Name}}'); do
  echo \"\$n\" | grep -qE 'hada|control|ingress' && { echo 'FAIL: existing HADA network: '\$n; exit 1; }
done
echo 'PASS: no unexpected HADA containers/volumes/networks'
" || { fail "Unexpected HADA resources present"; return 1; }
    pass "No unexpected HADA resources present"

    # 2f: verify /var/lib/hada mounted from correct persistent disk
    log "[2f] Verifying /var/lib/hada mount from persistent disk..."
    ssh_remote "verify-hada-mount" "
findmnt /var/lib/hada >/dev/null || { echo 'FAIL: /var/lib/hada not mounted'; exit 1; }
blkid /dev/sdb 2>/dev/null | grep -q 'a1574097-cdf9-4d0a-ace0-adac63038e56' || { echo 'FAIL: /dev/sdb UUID mismatch'; exit 1; }
echo 'PASS: /var/lib/hada mounted from correct persistent disk'
" || { fail "/var/lib/hada mount verification failed"; return 1; }
    pass "/var/lib/hada verified on correct persistent disk"

    # 2g: verify Docker Compose >= 2.24.4
    log "[2g] Verifying Docker Compose version >= 2.24.4..."
    ssh_remote "compose-version" "
v=\$(docker compose version --short 2>/dev/null | sed 's/^v//')
maj=\$(echo \$v | cut -d. -f1); min=\$(echo \$v | cut -d. -f2); pat=\$(echo \$v | cut -d. -f3)
if [ \$((maj*10000+min*100+pat)) -lt 20244 ]; then echo \"FAIL: compose \$v < 2.24.4\"; exit 1; fi
echo \"PASS: compose \$v >= 2.24.4\"
" || { fail "Compose version check failed"; return 1; }
    pass "Docker Compose version verified"

    log "GATE 2: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 3 — Provision production directories & permissions (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

provision_production_directories() {
    log "=============================================="
    log "GATE 3: Provision Production Directories & Permissions"
    log "=============================================="

    # 3a: docker-volume directories with explicit UID/GID/mode
    log "[3a] Creating docker-volume directories with correct ownership..."
    ssh_remote "create-volume-dirs" "
sudo install -d -o 70    -g 70    -m 0750 ${HADA_DOCKER_VOLUMES}/postgres-data
sudo install -d -o 999   -g 1000  -m 0770 ${HADA_DOCKER_VOLUMES}/valkey-data
sudo install -d -o 65534 -g 65534 -m 0755 ${HADA_DOCKER_VOLUMES}/prometheus-data
sudo install -d -o 10001 -g 10001 -m 0750 ${HADA_DOCKER_VOLUMES}/loki-data
sudo install -d -o 473   -g 473   -m 0770 ${HADA_DOCKER_VOLUMES}/alloy-data
sudo install -d -o 472   -g 0     -m 0750 ${HADA_DOCKER_VOLUMES}/grafana-data
sudo install -d -o 0     -g 0     -m 0755 ${HADA_DOCKER_VOLUMES}/caddy-data
sudo install -d -o 0     -g 0     -m 0755 ${HADA_DOCKER_VOLUMES}/caddy-config
echo PASS
" || { fail "create-volume-dirs failed"; return 1; }
    pass "Docker-volume directories created with correct ownership"

    # 3b: /opt/hada directory structure
    log "[3b] Creating /opt/hada directory structure..."
    ssh_remote "create-opt-hada" "
sudo install -d -o root -g hada -m 0750 ${OPT_HADA}
sudo install -d -o root -g hada -m 0750 ${OPT_HADA_COMPOSE}
sudo install -d -o root -g hada -m 0750 ${OPT_HADA_CADDY}
sudo install -d -o root -g hada -m 0750 ${OPT_HADA_SCRIPTS}
sudo install -d -o root -g hada -m 0750 ${OPT_HADA_CONFIG}
sudo install -d -o hada -g hada -m 0750 /var/lib/hada/evidence /var/lib/hada/keys /var/lib/hada/workspaces /var/lib/hada/repositories /var/log/hada
echo PASS
" || { fail "create-opt-hada failed"; return 1; }
    pass "/opt/hada directory structure created"

    # 3c: install overlay files to /opt/hada (root:hada, restrictive modes)
    log "[3c] Installing production overlay files to /opt/hada..."
    ssh_remote "install-overlay" "
sudo install -m 0644 -o root -g hada '${REMOTE_DIR}/compose.gcp.yaml' '${GCP_COMPOSE}'
sudo install -m 0644 -o root -g hada '${REMOTE_DIR}/Caddyfile.gcp' '${CADDYFILE_GCP}'
sudo install -m 0755 -o root -g hada '${REMOTE_DIR}/provision-secrets.sh' '${OPT_HADA_SCRIPTS}/provision-secrets.sh'
sudo install -m 0755 -o root -g hada '${REMOTE_DIR}/supervisor.sh' '${OPT_HADA_SCRIPTS}/supervisor.sh'
sudo install -m 0755 -o root -g hada '${REMOTE_DIR}/validate-host.sh' '${OPT_HADA_SCRIPTS}/validate-host.sh'
echo PASS
" || { fail "install-overlay failed"; return 1; }
    pass "Overlay files installed to /opt/hada"

    # 3d: guard — build context must already exist (bootstrap installed it)
    log "[3d] Verifying orchestrator build context present at /opt/hada..."
    ssh_remote "verify-build-context" "
[ -f '${OPT_HADA}/Dockerfile' ] || { echo 'FAIL: ${OPT_HADA}/Dockerfile missing (run bootstrap-ubuntu.sh first)'; exit 1; }
[ -d '${OPT_HADA}/src/hada' ] || { echo 'FAIL: ${OPT_HADA}/src/hada missing (run bootstrap-ubuntu.sh first)'; exit 1; }
[ -f '${BASE_COMPOSE}' ] || { echo 'FAIL: ${BASE_COMPOSE} missing'; exit 1; }
echo PASS
" || { fail "Build context verification failed"; return 1; }
    pass "Orchestrator build context verified at /opt/hada"

    log "GATE 3: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 4 — Validate production .env (real secrets, no printing) (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

validate_production_env() {
    log "=============================================="
    log "GATE 4: Validate Production .env (secure input)"
    log "=============================================="
    log "[4a] Real secrets must be provisioned out-of-band by provision-secrets.sh"
    log "     (run on host via IAP BEFORE this runner). They are NEVER accepted"
    log "     on the command line and NEVER printed by this runner."

    ssh_remote "validate-env" "
set -e
F='${OPT_HADA_ENV}'
[ -f \"\$F\" ] || { echo 'FAIL: ${OPT_HADA_ENV} missing — run provision-secrets.sh first'; exit 1; }
# ownership/perms must be root:hada 0640
own=\$(stat -c '%U:%G' \"\$F\"); perms=\$(stat -c '%a' \"\$F\")
[ \"\$own\" = 'root:hada' ] || { echo \"FAIL: ownership \$own expected root:hada\"; exit 1; }
[ \"\$perms\" = '640' ] || { echo \"FAIL: perms \$perms expected 640\"; exit 1; }
# no placeholder must remain
grep -q 'CHANGE_ME' \"\$F\" && { echo 'FAIL: CHANGE_ME placeholder remains in .env'; exit 1; }
# required keys present (check name presence only — values NEVER printed)
for k in POSTGRES_PASSWORD VALKEY_PASSWORD GRAFANA_ADMIN_PASSWORD HADA_DATABASE_DSN HADA_VALKEY_URL; do
  grep -q \"^\$k=\" \"\$F\" || { echo \"FAIL: missing \$k in .env\"; exit 1; }
done
echo PASS
" || { fail ".env validation failed"; return 1; }
    pass ".env validated (ownership root:hada 0640, no placeholders, required keys present; values not printed)"
    log "GATE 4: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 5 — Render & validate final Compose JSON (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

render_validate_compose() {
    log "=============================================="
    log "GATE 5: Render & Validate Final Compose JSON"
    log "=============================================="

    # Render effective compose using REAL .env (non-secret structural check)
    log "[5a] Rendering effective compose (real .env) to JSON..."
    ssh_remote "render-compose-real" "
cd '${OPT_HADA}' && sudo -n docker compose -p '${COMPOSE_PROJECT}' \
  -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' \
  --env-file '${OPT_HADA_ENV}' config --format json > '${REMOTE_DIR}/effective-compose.real.json' && echo RENDER_OK
" || { fail "compose render (real .env) failed"; return 1; }
    pass "Effective compose rendered with real .env"

    # Port assertion: exactly one published port, caddy, 127.0.0.1:80, no 443
    log "[5b] Port assertion (loopback-only, no 443)..."
    ssh_remote "port-assertion" "
python3 - <<'PY'
import json,sys
cfg=json.load(open('${REMOTE_DIR}/effective-compose.real.json'))
ports=[]
for svc,sv in cfg.get('services',{}).items():
    for p in sv.get('ports',[]) or []:
        pub=str(p.get('published')); tgt=str(p.get('target'))
        hip=str(p.get('host_ip','0.0.0.0')); proto=str(p.get('protocol','tcp'))
        ports.append((svc,hip,pub,tgt,proto))
errs=[]
if len(ports)!=1: errs.append('expected 1 published port, got %d'%len(ports))
for svc,hip,pub,tgt,proto in ports:
    if svc!='caddy': errs.append('published port not on caddy: %s'%svc)
    if hip!='127.0.0.1': errs.append('host_ip not loopback: %s'%hip)
    if pub not in ('80','80'): errs.append('published != 80: %s'%pub)
    if tgt not in ('80','80'): errs.append('target != 80: %s'%tgt)
    if proto!='tcp': errs.append('protocol != tcp: %s'%proto)
    if pub in ('443','443') or tgt in ('443','443'): errs.append('port 443 present')
if errs:
    print('FAIL'); [print(e) for e in errs]; sys.exit(1)
print('PASS: exactly one published port - caddy 127.0.0.1:80:80/tcp, no 443')
PY
" || { fail "Port assertion failed"; return 1; }
    pass "Port assertion: caddy 127.0.0.1:80 only, no 443"

    # Volume assertion: all 8 beneath /var/lib/hada/docker-volumes/
    log "[5c] Volume assertion (all 8 beneath /var/lib/hada/docker-volumes/)..."
    ssh_remote "volume-assertion" "
python3 - <<'PY'
import json,sys
cfg=json.load(open('${REMOTE_DIR}/effective-compose.real.json'))
vols=cfg.get('volumes',{})
expected={'postgres-data':'/var/lib/hada/docker-volumes/postgres-data',
 'valkey-data':'/var/lib/hada/docker-volumes/valkey-data',
 'prometheus-data':'/var/lib/hada/docker-volumes/prometheus-data',
 'loki-data':'/var/lib/hada/docker-volumes/loki-data',
 'alloy-data':'/var/lib/hada/docker-volumes/alloy-data',
 'grafana-data':'/var/lib/hada/docker-volumes/grafana-data',
 'caddy-data':'/var/lib/hada/docker-volumes/caddy-data',
 'caddy-config':'/var/lib/hada/docker-volumes/caddy-config'}
errs=[]
for name,vol in vols.items():
    do=vol.get('driver_opts',{})
    if do.get('type')!='none': errs.append('%s type=%s'%(name,do.get('type')))
    if do.get('o')!='bind': errs.append('%s o=%s'%(name,do.get('o')))
    dev=do.get('device','')
    if dev!=expected.get(name): errs.append('%s device=%s'%(name,dev))
    if not dev.startswith('/var/lib/hada/docker-volumes/'): errs.append('%s not beneath base'%name)
for name in expected:
    if name not in vols: errs.append('missing %s'%name)
if len(vols)!=8: errs.append('expected 8 volumes got %d'%len(vols))
if errs:
    print('FAIL'); [print(e) for e in errs]; sys.exit(1)
print('PASS: all 8 volumes type=none o=bind beneath /var/lib/hada/docker-volumes/')
PY
" || { fail "Volume assertion failed"; return 1; }
    pass "Volume assertion: all 8 volumes beneath /var/lib/hada/docker-volumes/"

    log "GATE 5: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 6 — Image pull / build (explicit list) (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

PULL_IMAGES=(
    "postgres:17-alpine"
    "valkey/valkey:8-alpine"
    "prom/prometheus:v3.2.1"
    "grafana/loki:3.4.2"
    "grafana/alloy:v1.12.0"
    "grafana/grafana:11.5.2"
    "caddy:2.10-alpine"
    "prom/node-exporter:v1.9.0"
)
ORCHESTRATOR_IMAGE="hada-orchestrator:0.2.0"

pull_build_images() {
    log "=============================================="
    log "GATE 6: Image Pull / Build"
    log "=============================================="
    log "[6a] Images to PULL (${#PULL_IMAGES[@]}):"
    local img
    for img in "${PULL_IMAGES[@]}"; do log "      - ${img}"; done
    log "[6b] Image to BUILD:"
    log "      - ${ORCHESTRATOR_IMAGE} (context ${OPT_HADA}, Dockerfile ${OPT_HADA}/Dockerfile)"

    # Pull all pinned images explicitly
    log "[6c] Pulling pinned images..."
    for img in "${PULL_IMAGES[@]}"; do
        log "      pull: ${img}"
        ssh_remote "pull-${img//[^a-zA-Z0-9]/_}" "
sudo -n docker pull '${img}' || { echo 'FAIL: pull ${img}'; exit 1; }
echo PULLED ${img}
" || { fail "pull failed: ${img}"; return 1; }
    done
    pass "All pinned images pulled"

    # Build orchestrator image (explicit project + files; uses base compose build)
    log "[6d] Building orchestrator image ${ORCHESTRATOR_IMAGE}..."
    ssh_remote "build-orchestrator" "
cd '${OPT_HADA}' && sudo -n docker compose -p '${COMPOSE_PROJECT}' \
  -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' \
  --env-file '${OPT_HADA_ENV}' build --no-cache orchestrator || { echo 'FAIL: build orchestrator'; exit 1; }
echo BUILT ${ORCHESTRATOR_IMAGE}
" || { fail "orchestrator build failed"; return 1; }
    pass "Orchestrator image built: ${ORCHESTRATOR_IMAGE}"

    log "GATE 6: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 7 — Database / service startup (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

start_services() {
    log "=============================================="
    log "GATE 7: Database / Service Startup"
    log "=============================================="
    log "[7a] Starting services (postgres, valkey first via depends_on health)..."
    ssh_remote "compose-up" "
cd '${OPT_HADA}' && sudo -n docker compose -p '${COMPOSE_PROJECT}' \
  -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' \
  --env-file '${OPT_HADA_ENV}' up -d --remove-orphans || { echo 'FAIL: compose up'; exit 1; }
echo UP_OK
" || { fail "compose up failed"; return 1; }
    pass "Services started (up -d)"
    log "GATE 7: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 8 — Health validation + loopback verification (bounded) (DEPLOY_EXECUTE)
# ----------------------------------------------------------------------------

health_validate() {
    log "=============================================="
    log "GATE 8: Health Validation & Loopback Verification"
    log "=============================================="

    # 8a: postgres healthy (bounded retry)
    log "[8a] Waiting for postgres health (bounded)..."
    ssh_remote "health-postgres" "
for i in \$(seq 1 30); do
  if sudo -n docker compose -p '${COMPOSE_PROJECT}' -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' --env-file '${OPT_HADA_ENV}' exec -T postgres pg_isready -U hada -d hada >/dev/null 2>&1; then
    echo 'POSTGRES_HEALTHY'; exit 0
  fi
  sleep 4
done
echo 'FAIL: postgres not healthy within timeout'; exit 1
" || { fail "postgres health timeout"; return 1; }
    pass "PostgreSQL healthy"

    # 8b: valkey auth ping (bounded retry)
    log "[8b] Waiting for valkey auth ping (bounded)..."
    ssh_remote "health-valkey" "
for i in \$(seq 1 30); do
  if sudo -n docker compose -p '${COMPOSE_PROJECT}' -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' --env-file '${OPT_HADA_ENV}' exec -T valkey valkey-cli -a \"\$(sudo -n grep '^VALKEY_PASSWORD=' '${OPT_HADA_ENV}' | cut -d= -f2)\" ping 2>/dev/null | grep -q PONG; then
    echo 'VALKEY_HEALTHY'; exit 0
  fi
  sleep 4
done
echo 'FAIL: valkey not healthy within timeout'; exit 1
" || { fail "valkey health timeout"; return 1; }
    pass "Valkey healthy and requires auth"

    # 8c: orchestrator /readyz (bounded retry)
    log "[8c] Waiting for orchestrator /readyz (bounded)..."
    ssh_remote "health-orchestrator" "
for i in \$(seq 1 40); do
  if sudo -n docker compose -p '${COMPOSE_PROJECT}' -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' --env-file '${OPT_HADA_ENV}' exec -T orchestrator python -c \"import urllib.request; urllib.request.urlopen('http://127.0.0.1:9108/readyz',timeout=3)\" >/dev/null 2>&1; then
    echo 'ORCHESTRATOR_READYZ'; exit 0
  fi
  sleep 6
done
echo 'FAIL: orchestrator not ready within timeout'; exit 1
" || { fail "orchestrator health timeout"; return 1; }
    pass "Orchestrator /readyz responding"

    # 8d: all services running
    log "[8d] Confirming all services running..."
    ssh_remote "services-running" "
out=\$(sudo -n docker compose -p '${COMPOSE_PROJECT}' -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' --env-file '${OPT_HADA_ENV}' ps --all --format json)
echo \"\$out\" | python3 -c 'import json,sys; d=json.load(sys.stdin); bad=[s[\"Service\"] for s in d if s.get(\"State\")!=\"running\"]; print(\"RUNNING\" if not bad else \"FAIL:\"+str(bad)); sys.exit(1 if bad else 0)'
" || { fail "not all services running"; return 1; }
    pass "All services running"

    # 8e: externally published socket is loopback-only (127.0.0.1:80)
    log "[8e] Verifying published socket is loopback-only..."
    ssh_remote "loopback-check" "
binds=\$(sudo -n ss -lntp 2>/dev/null | grep -E ':80\\b' | awk '{print \$4}')
echo \"binds=\$binds\"
echo \"\$binds\" | grep -q '127.0.0.1:80' || { echo 'FAIL: no 127.0.0.1:80 bind'; exit 1; }
echo \"\$binds\" | grep -qE '0.0.0.0:80|:::80' && { echo 'FAIL: port 80 bound on wildcard'; exit 1; }
echo 'PASS: caddy published only on 127.0.0.1:80'
" || { fail "loopback verification failed"; return 1; }
    pass "Published socket is loopback-only (127.0.0.1:80)"

    log "GATE 8: PASSED"
    return 0
}

# ----------------------------------------------------------------------------
# GATE 9 — Final state capture (no secrets) + bounded rollback procedure
# ----------------------------------------------------------------------------

capture_final_state() {
    log "=============================================="
    log "GATE 9: Final State Capture"
    log "=============================================="
    ssh_sudo_capture "docker-ps-final" "sudo -n docker ps -a" || { fail "ps-final capture failed"; return 1; }
    ssh_sudo_capture "docker-images-final" "sudo -n docker images" || { fail "images-final capture failed"; return 1; }
    ssh_sudo_capture "docker-volumes-final" "sudo -n docker volume ls" || { fail "volumes-final capture failed"; return 1; }
    ssh_sudo_capture "docker-networks-final" "sudo -n docker network ls" || { fail "networks-final capture failed"; return 1; }
    # Service status (compose ps) — no secret values
    ssh_remote "compose-status" "
sudo -n docker compose -p '${COMPOSE_PROJECT}' -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' --env-file '${OPT_HADA_ENV}' ps
" || { fail "compose status failed"; return 1; }
    pass "Final Docker state and service status captured (evidence contains no secrets)"
    log "GATE 9: PASSED"
    return 0
}

# Bounded rollback — NEVER deletes /var/lib/hada or persistent data.
# Called only on deployment failure. Uses 'down --remove-orphans' (NO -v).
bounded_rollback() {
    log "=============================================="
    log "BOUNDED ROLLBACK (non-destructive)"
    log "=============================================="
    log "Rollback will NOT run 'docker compose down -v', will NOT delete"
    log "/var/lib/hada, /opt/hada data, volumes, keys, evidence, or disks."

    ssh_remote "rb-stop-supervisor" "
sudo systemctl stop hada-supervisor.service 2>/dev/null || true
sudo systemctl disable hada-supervisor.service 2>/dev/null || true
echo RB_SUPERVISOR_STOPPED
" || log "WARN: supervisor stop failed (continuing rollback)"

    ssh_remote "rb-compose-down" "
cd '${OPT_HADA}' && sudo -n docker compose -p '${COMPOSE_PROJECT}' \
  -f '${BASE_COMPOSE}' -f '${GCP_COMPOSE}' \
  --env-file '${OPT_HADA_ENV}' down --remove-orphans 2>/dev/null || true
echo RB_COMPOSE_DOWN
" || log "WARN: compose down failed (continuing rollback)"

    ssh_remote "rb-remove-unit" "
sudo rm -f /etc/systemd/system/hada-supervisor.service && sudo systemctl daemon-reload
echo RB_UNIT_REMOVED
" || log "WARN: unit removal failed"

    log "Rollback complete. Persistent data preserved under /var/lib/hada."
    return 0
}

# ----------------------------------------------------------------------------
# Main flow
# ----------------------------------------------------------------------------

main() {
    log "=============================================="
    log "HADA M1 Phase B — Production Deployment Execution Gate"
    log "Timestamp: ${TIMESTAMP}"
    log "Evidence:  ${EVIDENCE_DIR}"
    log "DEPLOY_EXECUTE=${DEPLOY_EXECUTE}"
    log "=============================================="

    run_local_static_validation || { log "ABORT: Gate 0 failed"; exit 1; }
    verify_and_extract_candidate || { log "ABORT: Gate 1 failed"; exit 1; }

    if [[ "${DEPLOY_EXECUTE}" == "1" ]]; then
        log "DEPLOY_EXECUTE=1 — proceeding with remote deployment gates."
        remote_preparation_and_state_capture || { bounded_rollback; log "ABORT: Gate 2 failed"; exit 1; }
        provision_production_directories    || { bounded_rollback; log "ABORT: Gate 3 failed"; exit 1; }
        validate_production_env             || { bounded_rollback; log "ABORT: Gate 4 failed"; exit 1; }
        render_validate_compose             || { bounded_rollback; log "ABORT: Gate 5 failed"; exit 1; }
        pull_build_images                   || { bounded_rollback; log "ABORT: Gate 6 failed"; exit 1; }
        start_services                      || { bounded_rollback; log "ABORT: Gate 7 failed"; exit 1; }
        health_validate                     || { bounded_rollback; log "ABORT: Gate 8 failed"; exit 1; }
        capture_final_state                 || { log "WARN: Gate 9 capture failed"; }

        log "=============================================="
        log "DEPLOYMENT VALIDATION COMPLETE"
        log "Status: IMPLEMENTATION_CANDIDATE_AWAITING_PARTY_3"
        log "No autonomous repository work performed."
        log "=============================================="
    else
        log "DEPLOY_EXECUTE is not '1' — execution-gate review only."
        log "No SSH/SCP/deploy actions were performed."
        log "Re-run with DEPLOY_EXECUTE=1 to perform the deployment."
    fi

    write_gate_review
    log "Execution-gate review written to: ${EVIDENCE_DIR}/execution-gate-review.md"
    exit "${EXIT_STATUS}"
}

# ----------------------------------------------------------------------------
# Execution-gate review document
# ----------------------------------------------------------------------------

write_gate_review() {
    local out="${EVIDENCE_DIR}/execution-gate-review.md"
    {
        echo "# HADA M1 Phase B — Execution-Gate Review"
        echo
        echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "Runner: scripts/run-phase-b-deploy.sh"
        echo "DEPLOY_EXECUTE=${DEPLOY_EXECUTE}"
        echo
        echo "## Locked configuration"
        echo "- Candidate SHA-256: ${EXPECTED_CANDIDATE_SHA256}"
        echo "- Target: project=${TARGET_PROJECT} zone=${TARGET_ZONE} vm=${TARGET_VM}"
        echo "- Persistent disk mount: ${HADA_STATE_ROOT}"
        echo "- Compose project: ${COMPOSE_PROJECT}"
        echo "- Compose files: base + ${GCP_COMPOSE} (override, never standalone)"
        echo
        echo "## Gate results (local static validation)"
        echo "- Gate 0a bash -n: PASS"
        echo "- Gate 0b shellcheck: PASS"
        echo "- Gate 0c prohibited-op placement: PASS"
        echo "- Gate 0d target assertions: PASS"
        echo "- Gate 0e candidate checksum: PASS"
        echo "- Gate 0f Phase B0 evidence PASS: PASS"
        echo "- Gate 0g secret redaction: PASS"
        echo "- Gate 0h cleanup/rollback guards: PASS"
        echo "- Gate 0i pipeline rc capture: PASS"
        echo "- Gate 0j DEPLOY_EXECUTE gate: verified (value=${DEPLOY_EXECUTE})"
        echo
        echo "## 26 requirement coverage (fail-closed)"
        echo "1. Locked SHA-256 verified before remote — Gate 0e/1"
        echo "2. Phase B0 evidence PASS required — Gate 0f"
        echo "3. Target exact match — Gate 0d"
        echo "4. /var/lib/hada on persistent disk — Gate 2f"
        echo "5. Initial Docker state via sudo -n — Gate 2d"
        echo "6. Refuse if unexpected HADA resources — Gate 2e"
        echo "7. Never touch hermes-clean/home-hub — asserted in Gate 0c"
        echo "8. Only candidate-derived files — Gate 1b/3c"
        echo "9. Exact install path /opt/hada — config + Gate 3"
        echo "10. Explicit dir ownership/perms — Gate 3a/3b"
        echo "11. Real secrets via secure input — Gate 4 (provision-secrets.sh out-of-band)"
        echo "12. No secrets in logs/evidence/args — Gate 0g/4"
        echo "13. Validate .env without printing — Gate 4"
        echo "14. Render/validate Compose JSON pre-build — Gate 5a"
        echo "15. Only caddy 127.0.0.1:80, no 443 — Gate 5b"
        echo "16. All 8 volumes beneath /var/lib/hada/docker-volumes/ — Gate 5c"
        echo "17. Explicit image pull/build list — Gate 6"
        echo "18. Separated prep/pull/start/health — Gates 3/6/7/8"
        echo "19. Explicit project + compose files — all remote steps"
        echo "20. Pipeline rc capture — capture_rc/PIPESTATUS"
        echo "21. Bounded health timeouts — Gate 8 loops"
        echo "22. Loopback-only socket — Gate 8e"
        echo "23. Final state captured — Gate 9"
        echo "24. Bounded rollback — bounded_rollback()"
        echo "25. Never delete /var/lib/hada in rollback — bounded_rollback()"
        echo "26. Stop after validation; no repo work — main() end"
        echo
        echo "## Security review (deploy-time implications)"
        echo "- node-exporter: pid:host + /:/host:ro,rslave. Read-only host root; host"
        echo "  PID namespace visibility. Acceptable for metrics but grants broad host"
        echo "  filesystem read access. Mitigation: ro + rslave, no capabilities added"
        echo "  beyond baseline (cap_drop ALL), no-new-privileges."
        echo "- alloy: reads /var/lib/docker/containers read-only to scrape container"
        echo "  logs. Read-only bind; limited blast radius. Ensure docker socket NOT"
        echo "  mounted."
        echo "- orchestrator: writable /var/lib/hada (state, evidence, keys). Required"
        echo "  for durability; runs as UID 10001 (hada), read_only rootfs with tmpfs"
        echo "  for /tmp and /var/log/hada. Acceptable."
        echo "- caddy: NET_BIND_SERVICE only (no ALL). Binds 127.0.0.1:80 as root"
        echo "  (image runs as root). NET_BIND_SERVICE is minimal; 443 not published."
        echo "- postgres/valkey: cap_add CHOWN/DAC_OVERRIDE/FOWNER/SETGID/SETUID for"
        echo "  volume ownership fixup at startup. These are privileged but scoped to"
        echo "  data-dir ownership; combined with cap_drop ALL baseline. Consider"
        echo "  pre-chowning volumes (done in Gate 3a) to drop SETUID/SETGID if image"
        echo "  permits, but current override is acceptable for Phase B."
        echo
        echo "## Conclusion"
        if [[ "${DEPLOY_EXECUTE}" == "1" ]]; then
            echo "Deployment path executed under DEPLOY_EXECUTE=1; see console log and"
            echo "captured evidence for runtime results."
        else
            echo "Local execution-gate review complete. Runner is fail-closed and will"
            echo "not contact hada-control until DEPLOY_EXECUTE=1 is set explicitly."
        fi
    } > "${out}"
}

main "$@"
