# Hermes Autonomous Development Appliance (HADA)

HADA is a governed, self-provisioning autonomous software-engineering appliance. It is deliberately separate from Hermesctl: HADA provisions and operates the development environment; Hermesctl is the target repository developed within that environment.

## Milestone status

This repository implements **M0 — Governed Foundation**:

- immutable project charter and governance policy
- milestone/state schemas
- role separation for implementation and adversarial review
- external-review hand-off gate
- Ubuntu 24.04 bootstrap and validation
- Docker Compose control-plane services
- Prometheus, Grafana and Loki configuration
- Caddy ingress with secure defaults
- watchdog supervisor and bounded recovery policy
- CI checks and unit tests
- architecture, RFC, ADR, roadmap and runbooks

M0 intentionally stops before autonomous modification of Hermesctl. The governance gate requires a human to configure secrets, select approved local models, and identify the Hermesctl target repository before M1 can begin.

## Safety model

HADA is autonomous only inside explicit bounds. It cannot approve its own changes, weaken mandatory gates, silently broaden milestone scope, or continue after an external-review or human-input stop condition.

## Quick start

```bash
cp .env.example .env
# Edit .env and config/hada.yaml
sudo ./scripts/bootstrap-ubuntu.sh
./scripts/validate-host.sh
sudo systemctl enable --now hada-supervisor.service
```

For local validation without provisioning a GPU host:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -e '.[dev]'
pytest
hada validate-config --config config/hada.yaml
```

See `docs/runbooks/VAST_AI_PROVISIONING.md` for the fresh-instance workflow.
