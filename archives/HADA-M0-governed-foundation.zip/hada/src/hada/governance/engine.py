from __future__ import annotations

from dataclasses import dataclass

from hada.models import GateDecision, GateName, GateStatus, MilestoneState, StopReason


class GovernanceViolation(RuntimeError):
    pass


@dataclass(frozen=True)
class GovernanceResult:
    state: MilestoneState
    may_continue: bool
    message: str


class GovernanceEngine:
    def record_decision(self, state: MilestoneState, decision: GateDecision) -> GovernanceResult:
        if state.stop_reason not in {StopReason.NONE, StopReason.EXTERNAL_REVIEW_REQUIRED}:
            raise GovernanceViolation(f"milestone is stopped: {state.stop_reason}")

        if decision.gate not in state.gates:
            raise GovernanceViolation(f"unknown gate: {decision.gate}")

        if decision.gate == GateName.EXTERNAL_REVIEW and decision.reviewer_party != 3:
            raise GovernanceViolation("external review must be performed by Party 3")

        if decision.gate != GateName.EXTERNAL_REVIEW and decision.reviewer_party == 3:
            raise GovernanceViolation("Party 3 is reserved for the independent external-review gate")

        state.gates[decision.gate] = decision

        if decision.status in {GateStatus.REJECTED, GateStatus.BLOCKED}:
            state.stop_reason = StopReason.HUMAN_INPUT_REQUIRED
            return GovernanceResult(state, False, f"gate {decision.gate} did not pass")

        if state.is_complete():
            state.stop_reason = StopReason.MILESTONE_COMPLETE
            return GovernanceResult(state, False, "milestone complete")

        internal_gates = [
            GateName.ARCHITECTURE,
            GateName.SECURITY,
            GateName.TEST,
            GateName.DOCUMENTATION,
            GateName.MILESTONE_REPORT,
        ]
        if all(
            state.gates[g] is not None and state.gates[g].status == GateStatus.APPROVED
            for g in internal_gates
        ) and state.gates[GateName.EXTERNAL_REVIEW] is None:
            state.stop_reason = StopReason.EXTERNAL_REVIEW_REQUIRED
            return GovernanceResult(state, False, "external independent review required")

        state.stop_reason = StopReason.NONE
        return GovernanceResult(state, True, "next gate may proceed")
