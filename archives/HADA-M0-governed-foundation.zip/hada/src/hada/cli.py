from pathlib import Path

import typer
from rich.console import Console

from hada.config import load_config

app = typer.Typer(no_args_is_help=True)
console = Console()


@app.command("validate-config")
def validate_config(config: Path = typer.Option(..., exists=True, readable=True)) -> None:
    loaded = load_config(config)
    console.print(f"[green]valid[/green]: {loaded.project.name} -> {loaded.project.target_name}")
    if not loaded.project.target_repository:
        console.print("[yellow]stop condition[/yellow]: target_repository is not configured")
        raise typer.Exit(code=2)
    missing_models = [name for name, agent in loaded.agents.items() if agent.party in {1, 2} and not agent.model]
    if missing_models:
        console.print(f"[yellow]stop condition[/yellow]: models are missing for {', '.join(missing_models)}")
        raise typer.Exit(code=2)


@app.command("doctor")
def doctor() -> None:
    import shutil

    required = ["docker", "git", "curl", "jq"]
    missing = [binary for binary in required if shutil.which(binary) is None]
    if missing:
        console.print(f"[red]missing[/red]: {', '.join(missing)}")
        raise typer.Exit(code=1)
    console.print("[green]host prerequisites detected[/green]")
