from __future__ import annotations

from enum import StrEnum
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class GateName(StrEnum):
    ARCHITECTURE = "architecture"
    SECURITY = "security"
    TEST = "test"
    DOCUMENTATION = "documentation"
    MILESTONE_REPORT = "milestone_report"
    EXTERNAL_REVIEW = "external_review"


class GateStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    BLOCKED = "blocked"


class StopReason(StrEnum):
    NONE = "none"
    HUMAN_INPUT_REQUIRED = "human_input_required"
    EXTERNAL_REVIEW_REQUIRED = "external_review_required"
    CRITICAL_SECURITY_FINDING = "critical_security_finding"
    RECOVERY_EXHAUSTED = "recovery_exhausted"
    GOVERNANCE_VIOLATION = "governance_violation"
    MILESTONE_COMPLETE = "milestone_complete"


class GateDecision(BaseModel):
    model_config = ConfigDict(extra="forbid")

    gate: GateName
    status: GateStatus
    reviewer_party: int = Field(ge=1, le=3)
    subject_party: int = Field(ge=1, le=3)
    evidence: list[str] = Field(default_factory=list)
    findings: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def prevent_self_approval(self) -> "GateDecision":
        if self.status == GateStatus.APPROVED and self.reviewer_party == self.subject_party:
            raise ValueError("an agent may not approve its own work")
        return self


class MilestoneState(BaseModel):
    model_config = ConfigDict(extra="forbid")

    milestone_id: str
    title: str
    scope: list[str]
    out_of_scope: list[str]
    implementation_party: Literal[1] = 1
    gates: dict[GateName, GateDecision | None] = Field(
        default_factory=lambda: {gate: None for gate in GateName}
    )
    recovery_attempts: int = 0
    stop_reason: StopReason = StopReason.NONE

    def is_complete(self) -> bool:
        return all(
            decision is not None and decision.status == GateStatus.APPROVED
            for decision in self.gates.values()
        )


class ProjectConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    target_name: str
    target_repository: str
    target_ref: str
    workspace_root: Path


class GovernanceConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    require_architecture_review: bool
    require_security_review: bool
    require_test_review: bool
    require_documentation_update: bool
    require_milestone_report: bool
    require_external_review: bool
    prohibit_self_approval: bool
    prohibit_scope_expansion: bool
    maximum_recovery_attempts: int = Field(ge=0, le=10)
    maximum_agent_iterations_per_gate: int = Field(ge=1, le=20)
    stop_on_critical_security_finding: bool
    stop_on_external_review_unavailable: bool


class AgentConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    party: int = Field(ge=1, le=3)
    role: str
    model: str = ""
    endpoint: str | None = None
    mode: str | None = None


class InfrastructureConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    compose_file: Path
    health_check_interval_seconds: int = Field(ge=5, le=3600)
    startup_timeout_seconds: int = Field(ge=30, le=3600)
    recovery_backoff_seconds: int = Field(ge=1, le=3600)


class SecurityConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    allowed_egress_hosts: list[str]
    secrets_file: Path
    require_non_root_runtime: bool
    require_tls: bool
    redact_logs: bool


class HadaConfig(BaseModel):
    model_config = ConfigDict(extra="forbid")

    project: ProjectConfig
    governance: GovernanceConfig
    agents: dict[str, AgentConfig]
    infrastructure: InfrastructureConfig
    security: SecurityConfig

    @model_validator(mode="after")
    def validate_parties(self) -> "HadaConfig":
        parties = [agent.party for agent in self.agents.values()]
        if len(parties) != len(set(parties)):
            raise ValueError("each configured agent must use a distinct party number")
        if sorted(parties) != [1, 2, 3]:
            raise ValueError("parties 1, 2 and 3 must all be configured")
        return self
