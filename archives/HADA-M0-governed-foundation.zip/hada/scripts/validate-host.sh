#!/usr/bin/env bash
set -Eeuo pipefail

errors=0
check() {
  local description=$1
  shift
  if "$@" >/dev/null 2>&1; then
    printf 'PASS  %s\n' "$description"
  else
    printf 'FAIL  %s\n' "$description" >&2
    errors=$((errors + 1))
  fi
}

check "Ubuntu 24.04" grep -q '^VERSION_ID="24.04"' /etc/os-release
check "Docker daemon" docker info
check "Docker Compose" docker compose version
check "Git" git --version
check "Python 3.12+" python3 -c 'import sys; raise SystemExit(sys.version_info < (3,12))'
check "NVIDIA runtime or explicit CPU mode" bash -c 'command -v nvidia-smi >/dev/null || [[ ${HADA_ALLOW_CPU_ONLY:-false} == true ]]'
check "HADA environment file" test -r /opt/hada/.env
check "HADA config" test -r /opt/hada/config/hada.yaml

if (( errors > 0 )); then
  echo "$errors validation check(s) failed" >&2
  exit 1
fi

echo "Host validation passed"
