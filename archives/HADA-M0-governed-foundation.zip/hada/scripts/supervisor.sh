#!/usr/bin/env bash
set -Eeuo pipefail

cd /opt/hada
set -a
source .env
set +a

compose=(docker compose -f deploy/compose/compose.yaml --env-file .env)
max_attempts=$(python3 - <<'PY'
import yaml
with open('config/hada.yaml', encoding='utf-8') as f:
    print(yaml.safe_load(f)['governance']['maximum_recovery_attempts'])
PY
)

attempt=0
while true; do
  if ! "${compose[@]}" up -d --remove-orphans; then
    attempt=$((attempt + 1))
  elif "${compose[@]}" ps --format json | jq -e 'select(.State != "running" or (.Health != "" and .Health != "healthy"))' >/dev/null; then
    attempt=$((attempt + 1))
    "${compose[@]}" restart
  else
    attempt=0
  fi

  if (( attempt > max_attempts )); then
    logger -p daemon.crit -t hada-supervisor "recovery attempts exhausted"
    exit 70
  fi
  sleep 30
done
