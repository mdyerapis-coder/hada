#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run as root: sudo $0" >&2
  exit 1
fi

source /etc/os-release
if [[ ${ID} != ubuntu || ${VERSION_ID} != "24.04" ]]; then
  echo "HADA requires Ubuntu 24.04 LTS; found ${PRETTY_NAME}" >&2
  exit 1
fi

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends ca-certificates curl git jq python3 python3-venv python3-pip uidmap gnupg unattended-upgrades rsync
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg
cat >/etc/apt/sources.list.d/docker.sources <<DOCKER
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Signed-By: /etc/apt/keyrings/docker.gpg
DOCKER
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

if ! id hada >/dev/null 2>&1; then
  useradd --system --create-home --home-dir /var/lib/hada --shell /usr/sbin/nologin hada
fi
usermod -aG docker hada
install -d -o root -g hada -m 0750 /opt/hada
install -d -o hada -g hada -m 0750 /var/lib/hada /var/log/hada
rsync -a --delete --exclude '.git' ./ /opt/hada/
python3 -m venv /opt/hada/.venv
/opt/hada/.venv/bin/pip install --upgrade pip
/opt/hada/.venv/bin/pip install /opt/hada

install -m 0644 /opt/hada/scripts/hada-supervisor.service /etc/systemd/system/hada-supervisor.service
systemctl daemon-reload
systemctl enable docker

echo "Bootstrap complete. Configure /opt/hada/.env and /opt/hada/config/hada.yaml, then run validate-host.sh."
