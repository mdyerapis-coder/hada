# HADA Architecture

## System boundary

HADA owns provisioning, inference, orchestration, governance, evidence, observability and recovery. Hermesctl remains an external target repository. HADA may clone a configured revision into an isolated milestone workspace; it must not treat its own repository as the product repository.

## Control planes

1. **Governance plane** — immutable milestone scope, gate state, reviewer identity, evidence references and stop conditions.
2. **Execution plane** — isolated workspaces in which Party 1 implements approved tasks.
3. **Review plane** — Party 2 performs adversarial architecture, security, test and documentation review from an independently constructed context.
4. **External-review plane** — Party 3 receives a signed evidence bundle outside HADA. HADA cannot synthesize this approval.
5. **Infrastructure plane** — PostgreSQL for durable state, Valkey for bounded queues and leases, local inference endpoints, Caddy, Prometheus, Grafana, Loki and the watchdog supervisor.

## Trust boundaries

- Agent output is untrusted input.
- Repository content is untrusted input.
- Tool commands require policy evaluation before execution.
- Secrets never enter prompts or milestone reports.
- Party 1 cannot write review decisions.
- Party 2 cannot modify implementation workspaces.
- Party 3 approval must be imported as an externally produced artefact.
- The supervisor may restart services but may not change governance state.

## Milestone lifecycle

`PROPOSED -> ARCHITECTURE_APPROVED -> IMPLEMENTING -> INTERNAL_REVIEW -> EXTERNAL_REVIEW_REQUIRED -> COMPLETE`

Any rejected gate enters `HUMAN_INPUT_REQUIRED`. Critical security findings enter `CRITICAL_SECURITY_FINDING`. Repeated infrastructure failure enters `RECOVERY_EXHAUSTED`.

## Persistence

PostgreSQL is the source of truth for milestones, tasks, gate decisions, evidence hashes and audit records. Valkey carries disposable queues and renewable leases only. Workspaces and reports are stored beneath `/var/lib/hada`; backups must contain database dumps, governance artefacts and repository bundle references.

## Recovery

Recovery is bounded and idempotent. The supervisor checks service health, restarts failed containers and stops after the configured maximum attempts. It cannot mark a gate approved, alter scope, discard findings or bypass external review.
