# Roadmap

## M0 — Governed foundation

Repository structure, governance model, host bootstrap, base control-plane services, watchdog, CI and operating documentation.

## M1 — Durable orchestrator

PostgreSQL schema and migrations, signed audit log, Valkey queues, leases, workspace creation, task lifecycle and policy-enforced tool execution.

## M2 — Local inference plane

GPU discovery, approved model profiles, vLLM/SGLang deployment, readiness and load tests, resource admission control and model fallback policy.

## M3 — Party 1 implementation workflow

Hermesctl checkout, architecture-first task planning, patch production, deterministic test execution and evidence capture.

## M4 — Party 2 adversarial workflow

Independent context construction, threat modelling, architecture review, security review, mutation and regression testing, documentation review and rejection loops.

## M5 — Party 3 evidence exchange

Signed export bundle, external-review instructions, decision import, signer verification and immutable milestone closure.

## M6 — Production hardening

Backups and restore drills, GPU and disk pressure handling, SLOs, alerting, disaster recovery, supply-chain controls, SBOM, image signing and controlled upgrades.
