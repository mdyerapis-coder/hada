import pytest

from hada.governance.engine import GovernanceEngine, GovernanceViolation
from hada.models import GateDecision, GateName, GateStatus, MilestoneState, StopReason


def state() -> MilestoneState:
    return MilestoneState(
        milestone_id="M0",
        title="Foundation",
        scope=["governance"],
        out_of_scope=["Hermesctl changes"],
    )


def test_self_approval_rejected() -> None:
    with pytest.raises(ValueError):
        GateDecision(
            gate=GateName.ARCHITECTURE,
            status=GateStatus.APPROVED,
            reviewer_party=1,
            subject_party=1,
        )


def test_external_review_must_be_party_three() -> None:
    engine = GovernanceEngine()
    with pytest.raises(GovernanceViolation):
        engine.record_decision(
            state(),
            GateDecision(
                gate=GateName.EXTERNAL_REVIEW,
                status=GateStatus.APPROVED,
                reviewer_party=2,
                subject_party=1,
            ),
        )


def test_internal_gates_stop_at_external_review() -> None:
    engine = GovernanceEngine()
    current = state()
    for gate in [
        GateName.ARCHITECTURE,
        GateName.SECURITY,
        GateName.TEST,
        GateName.DOCUMENTATION,
        GateName.MILESTONE_REPORT,
    ]:
        result = engine.record_decision(
            current,
            GateDecision(
                gate=gate,
                status=GateStatus.APPROVED,
                reviewer_party=2,
                subject_party=1,
                evidence=["artifact"],
            ),
        )
        current = result.state
    assert current.stop_reason == StopReason.EXTERNAL_REVIEW_REQUIRED
    assert result.may_continue is False
